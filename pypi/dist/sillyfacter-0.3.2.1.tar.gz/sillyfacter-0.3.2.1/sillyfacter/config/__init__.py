# Set global variables here

VERSION = '0.3.2.1'
DEBUG = False
STRICT = False
