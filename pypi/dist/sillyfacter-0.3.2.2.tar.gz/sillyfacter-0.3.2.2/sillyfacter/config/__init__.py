# Set global variables here

VERSION = '0.3.2.2'
DEBUG = False
STRICT = False
